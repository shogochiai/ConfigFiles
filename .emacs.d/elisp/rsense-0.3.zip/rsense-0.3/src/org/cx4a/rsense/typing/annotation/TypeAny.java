package org.cx4a.rsense.typing.annotation;

public class TypeAny implements TypeExpression {
    public Type getType() {
        return Type.ANY;
    }
}
