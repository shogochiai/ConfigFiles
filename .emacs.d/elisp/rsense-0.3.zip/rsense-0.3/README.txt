RSense
======

Documentation
-------------

* http://cx4a.org/software/rsense/
* doc/index.txt

License
-------

RSense is distributed under the term of GPLv3+. And its documentations under doc directory is distributed under the term of GFDL.
